import {AuthorizationManager} from "@eryxcoop/appyx-comm";


export default class NaiveAuthorizationManager extends AuthorizationManager {

    configureHeaders(headers) {
    }
}
